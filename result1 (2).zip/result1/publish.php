
<?php


	include 'db.php';
if(!isset($_SESSION["username"]))
{
header("location: ./");
}



?>

                    <section class="main-content">
                            
                           
				<div class="row">
					
					<div class="span12">					
                                            <center><h4 class="title"><span class="text"><strong>PRODUCTS BOOKED</strong></span></h4></center>
                                            <!--<form action="#" method="post" class="form-stacked" enctype="multipart/form-data">-->
                                            <form name="sregister" class="form-stacked" id="form" method="POST" action="#" enctype="multipart/form-data" onSubmit="return valid()">
                                            <div class="span5"></div>
                    
<table width="1313">
  <tr>
    <td width="478">&nbsp;</td>
    <td width="320"><table border="1">
      <tr>
        <th>Product Id</th>
        
    
       
      </tr>
      <?php
//$qry="select * from login,role where login.role_id=role.role_id";
      $qry="select * from file";
$result=mysqli_query($con,$qry);
while($row=mysqli_fetch_array($result)){
?>
      <tr>
          <td><?php echo $row['file'];?></td>
<!--          <td><?php echo $row['book_id'];?></td>
           <td><?php echo $row['customer_id'];?></td>
        <td><?php echo $row['product_name'];?></td>
        <td><?php echo $row['first_name'];?></td>
         <td><?php echo $row['place_name'];?></td>-->
        
      
      
        
      </tr>
      <?php
}
?>
    </table></td>
    <td width="499">&nbsp;</td>
  </tr>
</table>

                                        </div>
		
		</section>		
    </body>
</html>
