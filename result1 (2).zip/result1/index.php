<?php
include 'db.php';

//login
if(isset($_POST['login']))
{
    header("location:login.php");
}    

//student registration
if(isset($_POST['submit1']))
{
    $a=$_POST["name"];
    $rno=$_POST["rollno"];
//    $dob=$_POST["dob"];
//    $password=$_POST["password"];
//    $p = $_POST["password1"];
    $e=$_POST["email"];
    $mobnum=$_POST["mobile_number"];
//    $j=$_POST["place_select"];
//    if ($p == $password) {
//        $sql1="INSERT INTO `r_userlogin`(`username`, `password`,`role_id`,`status`) VALUES ('$rno','$p','3',1)";
//        $result1=mysqli_query($con,$sql1);
//
//        $logid="SELECT `log_id` FROM `r_userlogin` WHERE `username`='$rno'";
//        $result2=mysqli_query($con,$logid);
//        while($row=mysqli_fetch_array($result2)){
//            $l=$row["log_id"];
            $sql2="INSERT INTO `r_student`(`roll_no`,`name`, `phno`, `email_id`, `sent_status`, `status`) VALUES ('$rno','$a','$mobnum','$e',0,0)";
//            echo $sql2;
            $res = mysqli_query($con, $sql2);
//            or die(mysqli_error($con))
//        }
        
        if($res==1){
            echo"<script>alert('Registration Successful!!Will contact you soon');</script>";
//            windows.header("location:index.php");
        }
        else{
            echo"<script>alert('Sorry email or username is already in use..Please choose a different one..! ');</script>)";
        }
//    }
//    else {
//        echo '<script language="javascript">';
//        echo 'alert("Your password does not match")';
//        echo '</script>';
//    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ASTHRA</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
        <link href="js/myjs.js">
        <link href="css/indexcss.css">
        <script src="js/index_stud.js"></script>
</head>
<body>
    
<!--    <div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>-->

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
	<!-- ====================================================header section -->
	<header class="top-header">
            <div class="container">
            	<div class="row">
                    <div class="col-xs-5 header-logo">
                        <br>
                        <a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
                    </div>
                    <div class="col-md-7">
			<nav class="navbar navbar-default">
			<div class="container-fluid nav-bar">
			<!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
				</button>
                            </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a class="menu active" href="#home" >Home</a></li>
                                    <li><a class="menu" href="#about">about us</a></li>
                                    <li><a class="menu" href="login.php">Login</a></li>
                                    <li><a class="menu" href="registration.php"> Registration</a></li>
                                    <li><div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script></li>
                                </ul>
                            </div><!-- /navbar-collapse -->
			 </div><!-- / .container-fluid -->
			</nav>
                    </div>
		</div>
            </div>
	</header> <!-- end of header area -->

			
			

<section class="slider" id="home">
				<div class="container-fluid">
					<div class="row">

					    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
							<div class="header-backup"></div><!--
					        <!-- Wrapper for slides -->
					        <div class="carousel-inner" role="listbox">
					            <div class="item active">
					            	<img src ="img/slide-one.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Results</h1>
				               			<p>RESULTS AT YOUR FINGER TIPS</p>
                                                                    <?php
                                                                    $check_pub1="SELECT count(*) as cnt FROM `r_result` WHERE `pub_status`=1";
                                                                    $result_sql1=mysqli_query($con,$check_pub1);
                                                                    $c1= mysqli_fetch_array($result_sql1);
                                                                    $check_pub2="SELECT count(*) as cnt FROM `r_result`";
                                                                    $result_sql2=mysqli_query($con,$check_pub2);
                                                                    $c2= mysqli_fetch_array($result_sql2);
                                                                    if($c1['cnt']==$c2['cnt']){
                                                                    ?>
                                                                <form action="stud_result_select_yr.php" method="$_POST">
				               			<button>Results</button>
                                                                    </form><?php } ?>
					                </div>
					            </div>
					            <div class="item">
					            	<img src="img/slide-two.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>results</h1>
				               			<p>RESULTS AT YOUR FINGER TIPS</p>
                                                                <?php 
                                                                if($c1['cnt']==$c2['cnt']){
                                                                ?>
                                                                <form action="stud_result_select_yr.php" method="$_POST">
				               			<button>Results</button>
                                                                    </form><?php } ?>
                                                                </form>
                                                                
					                </div>
					            </div>
					            <div class="item">
					            	<img src="img/slide-three.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Results</h1>
				               			<p>RESULTS AT YOUR FINGER TIPS</p>
                                                                <form action="stud_result_select_yr.php" method="$_POST">
                                                                <?php 
                                                                if($c1['cnt']==$c2['cnt']){
                                                                ?>
                                                                    <form action="stud_result_select_yr.php" method="$_POST">
				               			<button>Results</button>
                                                                    </form><?php } ?>
                                                                </form>
					                </div>
					            </div>
					            <div class="item">
					            	<img src="img/slide-four.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Results</h1>
				               			<p>RESULTS AT YOUR FINGER TIPS</p>
                                                                <form action="stud_result_select_yr.php" method="$_POST">
                                                                <?php 
                                                                if($c1['cnt']==$c2['cnt']){
                                                                ?>
                                                                    <form action="stud_result_select_yr.php" method="$_POST">
				               			<button>Results</button>
                                                                    </form><?php } ?>
                                                                </form>
					                </div>
					            </div>
					        </div>

					        <!-- Controls -->
					        <a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
					            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					            <span class="sr-only">Previous</span>
					        </a>
					        <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
					            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					            <span class="sr-only">Next</span>
					        </a>
					    </div>

					</div>
				</div>
			</section><!-- end of slider section -->






			<!-- about section -->
			<section class="about text-center" id="about">
				<div class="container">
					<div class="row">
						<h2>about us</h2>
						<h4>ASTHRA is committed to providing results of students who have attended the board exams.Based on the results the you can have the rank list also.ASTHRA also helps you to have a detailed study of the results.</h4>
						<div class="col-md-4 col-sm-6">
							<div class="single-about-detail clearfix">
								<div class="about-img">
									<img src="img/about1.jpg" alt="">
								</div>

								<div class="about-details">
									<div class="pentagon-text">
										<h1>I</h1>
									</div>

									<h3>Individual Results</h3>
									<p>Provides the individual results of a Registered user.</p>
								</div>
							</div>
						</div>

						<div class="col-md-4 col-sm-6">
							<div class="single-about-detail">
								<div class="about-img">
									<img class="img-responsive" src="img/about2.jpg" alt="">
								</div>

								<div class="about-details">
									<div class="pentagon-text">
										<h1>R</h1>
									</div>

									<h3>Result Reports</h3>
									<p>Provides detailed reports based on the results.</p>
								</div>
							</div>
						</div>


						<div class="col-md-4 col-sm-6">
							<div class="single-about-detail">
								<div class="about-img">
									<img class="img-responsive" src="img/about3.jpg" alt="">
								</div>

								<div class="about-details">
									<div class="pentagon-text">
										<h1>N</h1>
									</div>

									<h3>Notifications</h3>
									<p>Now Results are available immediatley at your finger tips.</p>
								</div>
							</div>
						</div>

					</div>
				</div>
			</section><!-- end of about section -->


			

			<!-- map section -->
			<section class="api-map" id="contact">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12 map" id="map"></div>
					</div>
				</div>
			</section><!-- end of map section -->

			

<!-- contact section starts here -->
			<section class="contact">
				<div class="container">
					<div class="row">
							<div class="contact-caption clearfix">
								<!--<div class="col-md-5 contact-heading text-left">
									<h2>Contact us</h2>
								</div>
								<div class="col-md-6 contact-heading text-right">
									<h2>Registration</h2>
								</div>
-->
								<div class="col-md-5 contact-info text-left">
									<h3>contact information</h3>
									<div class="info-detail">
										<ul><li><i class="fa fa-calendar"></i><span>Monday - Friday:</span> 9:30 AM to 6:30 PM</li></ul>
										<ul><li><i class="fa fa-map-marker"></i><span>Address:</span> 123 Some Street , California, US, CP 123</li></ul>
										<ul><li><i class="fa fa-phone"></i><span>Phone:</span> (01) 999-1235</li></ul>
										<ul><li><i class="fa fa-fax"></i><span>Fax:</span> (01) 999-1234</li></ul>
										<ul><li><i class="fa fa-envelope"></i><span>Email:</span> info@domain.com</li></ul>
									</div>
								</div>


								
                                                                <div class="col-md-6 col-md-offset-1 contact-form">
									<h3>Register yourself to get result notifications</h3>

                                                                        <form class="form" method="POST" id="form">
                                                                            <input type="text"  id="name" name="name"  placeholder="Name" class="name" onchange="f()" >
										<input class="name" id="rollno" name="rollno" type="text" placeholder="Roll Number">
                                                                                <input class="email" id="email" name="email" type="email" placeholder="Email" required>
                                                                                <input class="phone" id="mobile_number" name="mobile_number" type="text" placeholder="Phone No:" onchange="p()">
										<input class="submit-btn" name="submit1" id="submit1" type="submit" value="SUBMIT">
									</form>
								</div>

							</div>
					</div>
				</div>
			</section><!-- end of contact section -->


			<!-- footer starts here -->
			<footer class="footer clearfix">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 footer-para">
							<p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
						</div>

						<div class="col-xs-6 text-right">
							<a href=""><i class="fa fa-facebook"></i></a>
							<a href=""><i class="fa fa-twitter"></i></a>
							<a href=""><i class="fa fa-skype"></i></a>
						</div>
					</div>
				</div>
			</footer>



	

	<!-- script tags
	============================================================= -->
	<script src="js/jquery-2.1.1.js"></script>
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="js/gmaps.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script>
	
</body>
</html>