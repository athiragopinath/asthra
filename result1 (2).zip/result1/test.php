<?php
$xmlDoc = new DOMDocument();
$xmlDoc->load("C:\Python27\OUTPUTS\score.xml");
include 'db.php';

//$mysql_hostname = "localhost"; // Example : localhost
//$mysql_user     = "root";
//$mysql_password = "";
//$mysql_database = "result1";

//$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Oops some thing went wrong");
//echo $bd;
//mysqli_select_db($mysql_database, $con) or die("Oops some thing went wrong");
//$b=mysqli_select_db($con,'result1')or die("Oops some thing went wrong");
mysqli_select_db($con, 'result1');
$xmlObject = $xmlDoc->getElementsByTagName('Rollno');
$xmlObject1 = $xmlDoc->getElementsByTagName('mark');
$itemCount = $xmlObject->length;

for ($i=0; $i < $itemCount; $i++){
  $title = $xmlObject->item($i)->getElementsByTagName('Rollno')->item(0)->childNodes->item(0)->nodeValue;
  $link  = $xmlObject1->item($i)->getElementsByTagName('mark')->item(0)->childNodes->item(0)->nodeValue;
//  $sql   = "INSERT INTO `my_table_name` (title, url) VALUES ('$title', '$link')";
  $sql   = "INSERT INTO `r_results`(`roll_no`, `tot_marks`) VALUES ('$title', '$link')";
  mysql_query($sql);
  print "Finished Item $title n<br/>";
}
?>
<html><h1>haiii</h1></html>