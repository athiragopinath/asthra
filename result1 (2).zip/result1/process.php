<?php
echo '<script language="javascript">';
echo 'alert("Please Wait the results are being processed!!!")';
echo '</script>';
$xmlDoc = new DOMDocument();
$xmlDoc->load("score.xml");
$mysql_hostname = "localhost"; // Example : localhost
$mysql_user     = "root";
$mysql_password = "";
$mysql_database = "result1";

$bd = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) or die("Oops some thing went wrong");

$xmlObject = $xmlDoc->getElementsByTagName('Student_list');
$itemCount = $xmlObject->length;

for ($i=0; $i < $itemCount; $i++){
    
  $rollno = $xmlObject->item($i)->getElementsByTagName('Rollno')->item(0)->childNodes->item(0)->nodeValue;
  $mark  = $xmlObject->item($i)->getElementsByTagName('mark')->item(0)->childNodes->item(0)->nodeValue;

  $sql="INSERT INTO `r_result`(`roll_no`, `tot_marks`) VALUES ($rollno,$mark)";

    $res=mysqli_query($bd, $sql);
 
       
    header("location:result_processed.php");
}


//grade assigning
include 'db.php';
$sql1 = "SELECT * FROM `r_result`";
$result_sql11 = mysqli_query($con, $sql1) or die(mysqli_error($con));
$row1 = mysqli_fetch_array($result_sql1);
$i = 0;
while ($data = mysqli_fetch_array($result_sql11)) {
    $r = $data['result_id'];
    $m = $data['tot_marks'];
    $i++;
    if ($m > 950) {
        $sql1 = "UPDATE `r_result` SET `grade`='O' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    } else if ($m > 900) {
        $sql1 = "UPDATE `r_result` SET `grade`='A+' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    } elseif ($m > 800) {
        $sql1 = "UPDATE `r_result` SET `grade`='A' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    } elseif ($m > 700) {
        $sql1 = "UPDATE `r_result` SET `grade`='B+' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    } elseif ($m > 600) {
        $sql1 = "UPDATE `r_result` SET `grade`='B' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    } elseif ($m > 500) {
        $sql1 = "UPDATE `r_result` SET `grade`='C' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    } else {
        $sql1 = "UPDATE `r_result` SET `grade`='F' WHERE `result_id`=$r";
        $result_sql1 = mysqli_query($con, $sql1);
    }
    $sql_pub = "UPDATE `r_result` SET `pub_status`=1 WHERE `result_id`=$r";
    $result_sql1 = mysqli_query($con, $sql_pub) or die(mysqli_errno($con));
//    $i++;
}
//pass fail percentage
$sql9 = "SELECT COUNT(*) as cnt FROM `r_result`";
//echo $sql9;
$result_sql = mysqli_query($con, $sql9);
$count_tot_res = mysqli_fetch_array($result_sql);

$sql10 = "SELECT COUNT(*) as cnt FROM `r_result` WHERE `grade`!='F'";
//echo $sql10;
$result_sql10 = mysqli_query($con, $sql10);
$count_pass_res = mysqli_fetch_array($result_sql10);

if ($count_tot_res > 0) {
    $pass_percent = ($count_pass_res['cnt'] / $count_tot_res['cnt']) * 100;
//echo $pass_percent;
    $fail_percent = 100 - $pass_percent;
//echo $fail_percent;
    $count_pass = $count_pass_res['cnt'];
//echo $count_pass;
    $sql11 = "INSERT INTO `r_resultreport`(`pass_percent`, `fail_percent`) VALUES ($pass_percent,$fail_percent)";
//  echo $sql11;
    $result = mysqli_query($con, $sql11);
    // count of grades
    $sql2 = "SELECT count(*) as cnt FROM `r_result` WHERE `grade`='A+'";
    $result_sql2 = mysqli_query($con, $sql2);

    $sql3 = "SELECT count(*) as cnt  FROM `r_result` WHERE `grade`='A'";
    $result_sql3 = mysqli_query($con, $sql3);

    $sql4 = "SELECT count(*) as cnt  FROM `r_result` WHERE `grade`='B+'";
    $result_sql4 = mysqli_query($con, $sql4);

    $sql5 = "SELECT count(*)  as cnt FROM `r_result` WHERE `grade`='B'";
    $result_sql5 = mysqli_query($con, $sql5);

    $sql6 = "SELECT count(*) as cnt  FROM `r_result` WHERE `grade`='C'";
    $result_sql6 = mysqli_query($con, $sql6);

    $sql7 = "SELECT count(*) as cnt  FROM `r_result` WHERE `grade`='F'";
    $result_sql7 = mysqli_query($con, $sql7);

    $count_aplus = mysqli_fetch_array($result_sql2);
    $count_a = mysqli_fetch_array($result_sql3);
    $count_bplus = mysqli_fetch_array($result_sql4);
    $count_b = mysqli_fetch_array($result_sql5);
    $count_c = mysqli_fetch_array($result_sql6);
    $count_f = mysqli_fetch_array($result_sql7);

    $c_aplus = $count_aplus['cnt'];
    $c_a = $count_a['cnt'];
    $c_bplus = $count_bplus['cnt'];
    $c_b = $count_b['cnt'];
    $c_c = $count_c['cnt'];
    $c_f = $count_f['cnt'];
//    echo $c_aplus;
    $sql8 = "UPDATE `r_resultreport` SET `count_A+`=$c_aplus,`count_A`=$c_a,`count_B+`=$c_bplus,`count_B`=$c_b,`count_C`=$c_c,`count_F`=$c_f WHERE `report_id`=1";
    echo $sql8;
    $res_sql = mysqli_query($con, $sql8);
}
//header("location:result_processed.php");
?>