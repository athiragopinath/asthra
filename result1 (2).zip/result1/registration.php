<?php
include 'db.php';


//school registration
if (isset($_POST['submit'])) {
    $schnames = $_POST["names"];
//    $subdists = $_POST["subdist"];

//    $sb = $_POST["subcategory_select"];
    $passwords = $_POST["passwords"];
    $ps = $_POST["password1s"];
    
    
    			 //encription
	function encryptIt($q)
	{
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
	}
$encrp= encryptIt($ps);
    
    
    $es = $_POST["emails"];
    $mobnums = $_POST["mobile_numbers"];
    if ($ps == $passwords) {
        $sql1 = "INSERT INTO `r_userlogin`(`role_id`, `status`, `username`, `password`) VALUES (2,1,'$schnames','$encrp')";
        $result1 = mysqli_query($con, $sql1);

        $logid = "SELECT `log_id` FROM `r_userlogin` WHERE `username`='$schnames'";
        $result2 = mysqli_query($con, $logid);
        while ($row = mysqli_fetch_array($result2)) {

            $l = $row["log_id"];
            $sc=(rand(100000,900000));
            //$sql2=INSERT INTO `r_school`(`log_id`, `name`, `dist`, `subdist`, `email`, `phno`,`sec_code`,`status`) VALUES ('$l','$schnames',' $dists','$subdists','$es','$mobnums','$sc','1')";
            $sql2 = "INSERT INTO `r_school`(`log_id`, `name`,`email`, `phno`,`sec_code`, `status`) VALUES ('$l','$schnames','$es','$mobnums','$sc','0')";
            $res = mysqli_query($con, $sql2);
//          or die(mysqli_error($con))
        }
        if ($res == 1) {
            echo"<script>alert('Registration Successful Please Login');"
            . "window.location='login.php'</script>";

//            header("location:login.php");
        } else {
            echo"<script>alert('Sorry email or username is already in use..Please choose a different one..! ');</script>)";
        }
    } else {
        echo '<script language="javascript">';
        echo 'alert("Your password does not match")';
        echo '</script>';
    }
}
?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <script src="js/myjs.js"></script>
        <meta charset="UTF-8">
        <title>ASTHRA</title>
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/mystyle.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/newcss.css">
        <link rel="javascript" href="js/myjs.js">
        <script src="themes/js/jquery-1.7.2.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>				

        <script src="themes/js/superfish.js"></script>	
        <script src="themes/js/jquery.scrolltotop.js"></script>
    </head>
    <body>

        <!-- ====================================================
        header section -->
        <header class="top-header">
            <div class="container-fluid">
                <div class="col-xs-5 header-logo">
                    <br>
                    <a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
                </div>
                <div class="col-md-7">
                    <nav class="navbar navbar-default">
                        <div class="container-fluid nav-bar">
                            <!--Brand and toggle get grouped for better mobile display--> 
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <!--Collect the nav links, forms, and other content for toggling--> 
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right">
                                    <li><a class="menu active" href="index.php" >Home</a></li>
                                    <li><a class="menu" href="index.php">about us</a></li>
                                    <li><a class="menu" href="index.php">Contact us</a></li>
                                    <li><a class="menu" href="login.php"> Sign in</a></li><br>
                                    <!--<li style="float:right" class="style6"><h4>Logged in as <?php echo $_SESSION["username"]; ?></h4></li>-->
                                </ul>
                            </div> 
                        </div> 
                    </nav>
                </div>
            </div>

        </header> <!-- end of header area -->
        <br><br><br><br><br>
        <br><br><br>
        <!-- ====================================================body section -->
        <div class="container">
            <div class="row">
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <form id="my_form" name="my_form" method="POST" action="#" role="form">
                            <div class="form-group">
                                <h2>Register your School</h2>
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="signupName">Name of the school </label>
                                <input id="names" name="names" type="text" maxlength="50" class="form-control" onchange="f()" >
                            </div>

                            
                            <div class="form-group">
                                <label class="control-label" for="signupPassword">Password</label>
                                <input id="passwords" name="passwords" type="password" maxlength="25" class="form-control" onchange="pass()">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="signupPasswordagain">Password again</label>
                                <input id="signupPasswordagain" name="password1s" type="password" maxlength="25" class="form-control" onchange="pass1()">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="signupEmailagain">Email</label>
                                <input id="signupEmailagain" name="emails" type="email" maxlength="50" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="signupEmailagain">Contact Number</label>
                                <input id="mobile_numbers" name="mobile_numbers" type="text" maxlength="50" class="form-control" onchange="p()">
                            </div>
                            <div class="form-group">
                                <button id="signupSubmit" name="submit" type="submit" class="btn btn-info btn-block">Create your account</button>
                            </div>
                            <p class="form-group">By creating an account, you agree to our <a href="#">Terms of Use</a> and our <a href="#">Privacy Policy</a>.</p>
                            <hr>
                            <p></p>Already have an account? <a href="login.php">Sign in</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <footer class="footer clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 footer-para">
                        <p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
                    </div>

                    <div class="col-xs-6 text-right">
                        <a href=""><i class="fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-skype"></i></a>
                    </div>
                </div>
            </div>
            <script src="themes/js/common.js"></script>
            <script>
                                    $(document).ready(function () {
                                        $('#checkout').click(function (e) {
                                            document.location.href = "checkout.html";
                                        })
                                    });

                                    $('body').on('click', '#submit1', function () {
                                        $.ajax({
                                            type: 'post',
                                            url: 'exec/data_save.php',
                                            data: {context: 'save_product'},
                                            success: function (response)
                                            {
//                        alert(response);
                                            }});
                                    });

                                    $('body').on('change', '#category_select', function () {
//            alert("countryslected");
                                        $index = $('#category_select').val();
//            $index_id=$('#category_select option selected').val();
//            $('#category_select option:selected').val();
//              $index_id=$('#subcategory_select option selected').val();
//            $('#subcategory_select option:selected').val();
                                        $.ajax({
                                            type: 'post',
                                            url: 'get_subcategory.php',
                                            data: {index: $index},
                                            success: function (response)
                                            {
//                        alert(response);
                                                console.log(response);
                                                $ar = response.split(",");
                                                $str = "<option value='-1' disabled hidden selected> </option>";
                                                for (var i = 0; i < $ar.length; i++)
                                                {
                                                    $ss = $ar[i].split(':');
                                                    $str += '<option value=' + $ss[0] + '>' + $ss[1] + "</option>";
                                                }
                                                $('#subcategory_select').html($str);
                                            }
                                        });

                                    });

                                    $('body').on('change', '#subcategory_select', function () {
//            alert("countryslected");
                                        $index = $('#subcategory_select').val();
                                        $index_id = $('#subcategory_select option selected').val();
                                        $('#subcategory_select option:selected').val();
                                        $.ajax({
                                            type: 'post',
//                    url:'get_subcategory.php',
                                            data: {index: $index},
                                            success: function (response)
                                            {
//                        alert(response);
                                                console.log(response);
                                                $ar = response.split(",");
                                                $str = "<option value='-1' disabled hidden selected> </option>";
                                                for (var i = 0; i < $ar.length; i++)
                                                {
                                                    $ss = $ar[i].split(':');
                                                    $str += '<option value=' + $ss[0] + '>' + $ss[1] + "</option>";
                                                }
//                    $('#subcategory_select').html($str);
                                            }
                                        });

                                    });



            </script>	

    </body>
</html>