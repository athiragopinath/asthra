$(function() {

    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});

});

//validation

function f(){

    var val_fname= /^[A-Za-z]+$/;
    $names= document.getElementById('names').value;
    if(!val_fname.test($names)){
        alert("First Name Must be Alphabets Only");
	document.getElementById('names').value='';
	$("#names").focus();
        return false;
    }
}
function s(){

 var val_sname= /^[A-Za-z]+$/;
 $sname= document.getElementById('sname').value;

 if(!val_sname.test($sname)){

    alert("Last Name Must be Alphabets Only");
   document.getElementById('sname').value='';
   $("#sname").focus();
    return false;
  }

}
function p(){

	  var val_phone= /^[0-9]{9,12}$/;
	 $mobile_numbers= document.getElementById('mobile_numbers').value;

	 if(!val_phone.test($mobile_numbers)){

      alert("enter valid phone number");
	   document.getElementById('mobile_numbers').value='';
	   $("#mobile_numbers").focus();
      return false;
    }

}
function h(){

 var val_hname= /^[A-Za-z]+$/;
 $hname= document.getElementById('hname').value;

 if(!val_hname.test($hname)){

    alert("House Name Must be Alphabets Only");
   document.getElementById('hname').value='';
   $("#hname").focus();
    return false;
  }

}
function c(){

 var val_cname= /^[A-Za-z]+$/;
 $cname= document.getElementById('cname').value;

 if(!val_cname.test($cname)){

    alert("City Name Must be Alphabets Only");
   document.getElementById('cname').value='';
   $("#cname").focus();
    return false;
  }

}
function d(){

 var val_district= /^[A-Za-z]+$/;
 $district= document.getElementById('district').value;

 if(!val_district.test($hname)){

    alert("House Name Must be Alphabets Only");
   document.getElementById('district').value='';
   $("#district").focus();
    return false;
  }

}
function u(){

	  var val_uadhar= /^[0-9]{14,16}$/;
	 $uadhar= document.getElementById('uadhar').value;

	 if(!val_uadhar.test($uadhar)){

      alert("enter valid aadhar number");
	   document.getElementById('uadhar').value='';
	   $("#uadhar").focus();
      return false;
    }

}
function pass(){
				
				var val_pass=/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
				$passwords= document.my_form.passwords.value;
				if (!val_pass.test($passwords)){
					
					  alert("Required atleast one number, one lowercase and one uppercase letter, atleast six characters");
						document.my_form.passwords.value
					$("#passwords").focus();
					return false;
					
				}
}
function pass1(){
				
				var val_pass=/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
				$password1s= document.my_form.password1s.value;
				if (!val_pass.test($password1s)){
					
					  alert("Required atleast one number, one lowercase and one uppercase letter, atleast six characters");
						document.my_form.password1s.value
					$("#password1s").focus();
					return false;
					
				}
}

//student reg validation
function f1(){

    var val_fname= /^[A-Za-z]+$/;
    $name= document.getElementById('name').value;
    if(!val_fname.test($name)){
        alert("First Name Must be Alphabets Only");
	document.getElementById('name').value='';
	$("#name").focus();
        return false;
    }
}