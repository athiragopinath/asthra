function f(){

    var val_fname= /^[A-Za-z]+$/;
    $name= document.getElementById('name').value;
    if(!val_fname.test($name)){
        alert("First Name Must be Alphabets Only");
	document.getElementById('name').value='';
	$("#name").focus();
        return false;
    }
}

function r(){

	  var val_phone= /^[0-9]{6,6}$/;
	 $rollno= document.getElementById('rollno').value;

	 if(!val_phone.test($rollno)){

      alert("enter valid roll number");
	   document.getElementById('rollno').value='';
	   $("#rollno").focus();
      return false;
    }

}

function p(){

	  var val_phone= /^[0-9]{9,12}$/;
	 $mobile_number= document.getElementById('mobile_number').value;

	 if(!val_phone.test($mobile_number)){

      alert("enter valid phone number");
	   document.getElementById('mobile_number').value='';
	   $("#mobile_number").focus();
      return false;
    }

}