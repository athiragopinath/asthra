<?php
$xmlDoc = new DOMDocument();
$xmlDoc->load("score1.xml");
$mysql_hostname = "localhost"; // Example : localhost
$mysql_user     = "root";
$mysql_password = "";
$mysql_database = "result1";

$bd = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) or die("Oops some thing went wrong");
//mysql_select_db($mysql_database, $bd) or die("Oops some thing went wrong");

$xmlObject = $xmlDoc->getElementsByTagName('item');
$itemCount = $xmlObject->length;

for ($i=0; $i < $itemCount; $i++){
    //$topics = $xmlDoc-> getElementsByTagName('rollno');
    //echo( "<li>" . $topics->textContent . "</li>" );
    echo "jewhfkWJEBFLJWEHBGEJ";
  $rollno = $xmlObject->item($i)->getElementsByTagName('rollnum')->item(0)->childNodes->item(0)->nodeValue;
  $mark  = $xmlObject->item($i)->getElementsByTagName('marks')->item(0)->childNodes->item(0)->nodeValue;
//  $sql   = "INSERT INTO `my_table_name` (title, url) VALUES ('$title', '$link')";
  $sql="INSERT INTO `r_results`(`roll_no`, `tot_marks`, `rank_status`) VALUES ('$rollno','$mark','0')";
  mysqli_query($bd,$sql);
  print "Finished Item $rollno <br/>";
}
?>


