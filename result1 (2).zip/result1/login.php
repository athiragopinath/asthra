<?php
include 'db.php'; //database connection page
if (isset($_POST["submit"])) {
//    $url = 'https://www.google.com/recaptcha/api/siteverify';
//    $privatekey = "6LfEg0EUAAAAAAiYw0NJccw6uNZaig4XOf8YzIIr";
//    $response = file_get_contents($url . "?secret=" . $privatekey . "&response=" . $_POST['g-recaptcha-response'] . "&remoteip=" . $_SERVER['REMOTE_ADDR']);
//    $data = json_decode($response);

//    if (isset($data->success) AND $data->success == true) {
        
    $username = $_POST["username"];   //username value from the form
    $password = $_POST["password"]; //password value from the form
    //echo $username;
    	 //encription
	function encryptIt($q)
	{
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
	}
$encrp= encryptIt($password);
    
    
    $sql = "select * from r_userlogin where username='$username' and password ='$encrp'"; //value querried from the table
    $res = mysqli_query($con, $sql);  //query executing function
    if ($res) {

        if ($fetch = mysqli_fetch_array($res)) {
            if ($fetch['role_id'] == 1) {
//			$_SESSION["name"]=$fetch['name'];
                $_SESSION["log_id"] = $fetch['log_id'];
                $_SESSION["username"] = $username; // setting username as session variable 
                header("location:adminhome.php"); //home page or the dashboard page to be redirected
            } else {
                $_SESSION["username"] = $username; // setting username as session variable 
                $_SESSION["log_id"] = $fetch['log_id'];
                $us_id = $_SESSION["log_id"];
                $sql3 = "SELECT * FROM `r_school` WHERE `status`='1'";
                $result3 = mysqli_query($con, $sql3);
                $row = mysqli_fetch_array($result3);
                $us = $row['status'];
                if ($us == 1) {
                    header("location:schoolhome.php");
                } 
                elseif ($us == 0) {
                    echo "<script>alert('Your account is not approved yet!!')</script>";
                }
            }
        } else {
            echo "<script>alert('invalid credentials!')</script>";
        }
    }
    
     }	
//    else{
//        echo '<script> alert("captcha fail");</script>';
//    }
//}
?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ASTHRA</title>
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
        <script src='https://www.google.com/recaptcha/api.js'></script>
    </head>
    <body>

        <!-- ====================================================
        header section -->
        <header class="top-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-5 header-logo">
                        <br>
                        <a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
                    </div>

                    <div class="col-md-7">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid nav-bar">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                                    <ul class="nav navbar-nav navbar-right">
                                        <li><a class="menu active" href="index.php" >Home</a></li>
                                        <li><a class="menu" href="index.php">about us</a></li>
                                        <li><a class="menu" href="index.php">Contact us</a></li>
                                        <li><a class="menu" href="registration.php">Register</a></li>
                                    </ul>
                                </div><!-- /navbar-collapse -->
                            </div><!-- / .container-fluid -->
                        </nav>
                    </div>
                </div>
            </div>
        </header> <!-- end of header area -->




        <section class="slider" id="home" align="center">
            <div class="container-fluid">
                <div class="row">
                    <br><br><br><br><br><br><br><br>
                    <br><br><br><br>
                    <div class="" role="listbox">
                        <div  ><center ><h4 class="title"><span class="text"><strong>Login</strong></span></h4></center></div><br>
                        <form action="#" method="post">
                            <input type="hidden" name="next" value="/"><div class="span5"></div>
                            <fieldset>
                                <div class="control-group">
                                    <label class="control-label"><b>Username</b></label>
                                    <div class="controls">
                                        <input type="text" placeholder="Enter your username" id="username" name="username" class="input-xlarge" required/>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label"><b>Password</b></label>
                                    <div class="controls">
                                        <input type="password" placeholder="Enter your password" id="password" name="password" class="input-xlarge" required/>
                                   
                                    </div>
                                    
                                </div>
                            
                            </fieldset>
                            
                            <center>
                                <br>
                                <!--<div class="g-recaptcha" data-sitekey="6LfEg0EUAAAAAIFbRAtHoETVBNXWYTZPllQFXYbD"></div>-->
                                <div class="control-group"><br>
                                    <input tabindex="3" class="btn btn-inverse large" type="submit" id="submit" name="submit" value="Sign into your account">
                                    <hr><br>
                                      <p class="reset">Recover your <a tabindex="4" href="pass_recovery.php" title="Recover your username or password">username or password</a></p>
                                </div></center>

                        </form>	

                    </div><!--

                    <!--					         Controls -->
                    <!--					        <a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
                                                                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                                                        <span class="sr-only">Previous</span>
                                                                    </a>
                                                                    <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
                                                                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                                                        <span class="sr-only">Next</span>
                                                                    </a>-->
                </div>
            </div>
        </div>
    </div>
</section><!-- end of slider section -->




<!-- footer starts here -->
<footer class="footer clearfix">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 footer-para">
                <p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
            </div>

            <div class="col-xs-6 text-right">
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-skype"></i></a>
            </div>
        </div>
    </div>
</footer>





<!-- script tags
============================================================= -->
<script src="js/jquery-2.1.1.js"></script>
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src="js/gmaps.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
