<?php
include 'db.php'; //database connection page
if (isset($_POST["submit"])) {
    $sec_code = $_POST["seccode"];   //username value from the form
    $password = $_POST["newpass"]; //password value from the form
    $passcon = $_POST["newpasscon"];
//    echo $sec_code;
//    echo $password;
//    echo $passcon;
    
    if($password==$passcon){
//    echo "dvjhkjhvksjhvkj";
        
    $sql = "select * from r_school as s,r_userlogin as u where s.sec_code=$sec_code and u.log_id=s.log_id"; //value querried from the table
//    echo $sql;
    $res = mysqli_query($con, $sql);  //query executing function
    if ($res) {
        if ($fetch = mysqli_fetch_array($res)) {
            $lid=$fetch['log_id'];
//            echo $lid;
            $sql1="UPDATE `r_userlogin` SET `password`=$password WHERE `log_id`=$lid";
//            echo $sql1;
            $res1= mysqli_query($con,$sql1);
             echo "<script>alert('Your password is reset!!!')</script>";
        }
        else {
            echo "<script>alert('Wrong Security Code!!!')</script>";
        }
    }
}
else {
            echo "<script>alert('Passwords doesn't match!!!')</script>";
}
}
?>




<!DOCTYPE html>
<html lang="en">
    <head>
        <script src="js/myjs.js"></script>
        <meta charset="UTF-8">
        <title>ASTHRA</title>
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
    </head>
    <body>

        <!-- ====================================================
        header section -->
        <header class="top-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-5 header-logo">
                        <br>
                        <a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
                    </div>

                    <div class="col-md-7">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid nav-bar">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                                    <ul class="nav navbar-nav navbar-right">
                                        <li><a class="menu active" href="index.php" >Home</a></li>
                                        <li><a class="menu" href="index.php">about us</a></li>
                                        <li><a class="menu" href="index.php">Contact us</a></li>
                                        <li><a class="menu" href="registration.php">Register</a></li>
                                    </ul>
                                </div><!-- /navbar-collapse -->
                            </div><!-- / .container-fluid -->
                        </nav>
                    </div>
                </div>
            </div>
        </header> <!-- end of header area -->



    <center>
        <section class="slider" id="home" align="center">
            <div class="span4">
            </div>
            <div>
                <div class="row">
                    <br><br><br><br>
                    <br><br><br><br>
                    <div class="" role="listbox">
                        <div  ><center ><h4 class="title"><span class="text"><strong>PASSWORD RECOVERY</strong></span></h4></center></div><br>
                        <table align="center" border="1" width="500">   

                                    <form id="my_form" name="my_form" method="POST"  role="form">
                                        
                                        <tr><div class="form-group"><br>
                                            <td><label class="control-label">SECURITY CODE:</label></td>
                                            <td><input id="seccode" name="seccode" type="text" maxlength="25" class="form-control" ></td><td></td>
                                        </div></tr>
                                        <tr><div class="form-group"><br>
                                            <td><label class="control-label">NEW PASSWORD:</label></td>
                                            <td><input id="newpass" name="newpass" type="password" maxlength="25" class="form-control" onchange="pass()"></td><td></td>
                                        </div></tr>
                                        <tr><div class="form-group"><br>
                                            <td><label class="control-label">CONFIRM NEW PASSWORD:</label></td>
                                            <td><input id="newpasscon" name="newpasscon" type="password" maxlength="25" class="form-control" onchange="pass()"></td><td></td>
                                        </div></tr>
                                        <tr><div class="form-group"><td></td>
                                            <td><button id="signupSubmit" name="submit" type="submit" class="btn btn-info btn-block">SUBMIT</button></td><td></td>
                                        
                                        </div></tr>
                                    </form>   
                                    <!--</div>-->
                                </tr></table>
                      
                        <br><br><br><br><br><br><br><br><br><br><br><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- end of slider section -->




<!-- footer starts here -->
<footer class="footer clearfix">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 footer-para">
                <p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
            </div>

            <div class="col-xs-6 text-right">
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-skype"></i></a>
            </div>
        </div>
    </div>
</footer>





<!-- script tags
============================================================= -->
<script src="js/jquery-2.1.1.js"></script>
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src="js/gmaps.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>


 



