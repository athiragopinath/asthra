import sys
program_name = sys.argv[0]
arguments = sys.argv[1:]
count = len(arguments)
print count
