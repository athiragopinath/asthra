
	function f(){

	 var val_fname= /^[A-Za-z]+$/;
	 $fname= document.getElementById('fname').value;

	 if(!val_fname.test($fname)){

      alert("First Name Must be Alphabets Only");
	   document.getElementById('fname').value='';
	   $("#fname").focus();
      return false;
    }

}
function s(){

 var val_sname= /^[A-Za-z]+$/;
 $sname= document.getElementById('sname').value;

 if(!val_sname.test($sname)){

    alert("Last Name Must be Alphabets Only");
   document.getElementById('sname').value='';
   $("#sname").focus();
    return false;
  }

}
function p(){

	  var val_phone= /^[0-9]{9,12}$/;
	 $phone= document.getElementById('phone').value;

	 if(!val_phone.test($phone)){

      alert("enter valid phone number");
	   document.getElementById('phone').value='';
	   $("#phone").focus();
      return false;
    }

}
function h(){

 var val_hname= /^[A-Za-z]+$/;
 $hname= document.getElementById('hname').value;

 if(!val_hname.test($hname)){

    alert("House Name Must be Alphabets Only");
   document.getElementById('hname').value='';
   $("#hname").focus();
    return false;
  }

}
function c(){

 var val_cname= /^[A-Za-z]+$/;
 $cname= document.getElementById('cname').value;

 if(!val_cname.test($cname)){

    alert("City Name Must be Alphabets Only");
   document.getElementById('cname').value='';
   $("#cname").focus();
    return false;
  }

}
function d(){

 var val_district= /^[A-Za-z]+$/;
 $district= document.getElementById('district').value;

 if(!val_district.test($hname)){

    alert("House Name Must be Alphabets Only");
   document.getElementById('district').value='';
   $("#district").focus();
    return false;
  }

}
function u(){

	  var val_uadhar= /^[0-9]{14,16}$/;
	 $uadhar= document.getElementById('uadhar').value;

	 if(!val_uadhar.test($uadhar)){

      alert("enter valid aadhar number");
	   document.getElementById('uadhar').value='';
	   $("#uadhar").focus();
      return false;
    }

}
