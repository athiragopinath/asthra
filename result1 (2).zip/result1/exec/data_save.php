<?php

include_once '../db.php';
$action = $_POST['context'];
if ($action == 'save_product') {
save_product();
}
elseif($action == 'subcategory')
{
get_sub_category();
}
function save_product()
{
    //echo 'fsdfsfs';
    
    if(isset($_POST['submit']))
    {
        $distid=$_POST['subcategory_id'];
        $subdist=$post['subdist'];
//    $subcatname=$_POST['product_name'];
//    $desc=$_POST['description'];
//    $img=$_POST['image'];
   
    
        $sql="INSERT INTO `r_subdist`(`dist_id`, `subdist_name`) VALUES ('$distid','$subdist')";
        echo $sql;
   
        $sql->execute();
    }
    echo"<script>alert('Sub district added!!');</script>";
}




