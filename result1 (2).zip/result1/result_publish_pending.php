<?php
include 'db.php';
if (!isset($_SESSION["username"])) {
    header("location: ./");
}
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['submit3'])) {

    $sql = "SELECT COUNT(*) FROM `r_school`";
    $result1 = mysqli_query($con, $sql);
    $sql1 = "SELECT COUNT(*) FROM `r_school` WHERE `upload_status`='1'";
    $result2 = mysqli_query($con, $sql1);

    while ($row1 = mysqli_fetch_array($result1)) {
        while ($row2 = mysqli_fetch_array($result2)) {
            echo"<script>alert(</script>$row1<script>);</script>";
            if ($row1 == $row2) {
                header("location:result_process_ready.php");
            } else {
                header("location:result_process_pending.php");
            }
        }
    }
}
if (isset($_POST['submit4'])) {
    $query = "SELECT * FROM `r_results` ";
    $result = mysqli_query($con, $query);
    $rowzz = mysqli_fetch_array($result);
    if (!$rowzz) {
        header("location:verify_students_pending.php");
    } else {
        header("location:verify_students.php");
    }
}

if (isset($_POST['submit5'])) {
    $query = "SELECT * FROM `r_results` ";
    $result = mysqli_query($con, $query);
    $rowzz = mysqli_fetch_array($result);
    if (!$rowzz) {
        header("location:result_publish_pending.php");
    } else {
        header("location:result_publish_ready.php");
    }
}
if (isset($_POST['submit7'])) {

    header("location:approve_schools.php");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ASTHRA</title>
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
        <style>
            .button {
                background-color: orange;
                border: none;
                color: white;
                border-radius:13px 13px 13px 13px;
                /*padding: 16px 32px;*/
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                -webkit-transition-duration: 0.4s; /* Safari */
                transition-duration: 0.4s;
                cursor: pointer;
            }

            .button1 {
                background-color: #049dff ; 
                color:  white   ; 
                border: 2px solid white;
            }

            .button1:hover {
                background-color: #049dff;
                color: white;
            }

        </style>
    </head>
    <body>

        <!-- ====================================================
        header section -->
        <header class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-xs-5 header-logo">
                        <br>
                        <a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
                    </div>

                    <div class="col-md-7">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid nav-bar">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                                    <ul class="nav navbar-nav navbar-right">
<!--                                        <li><a class="menu active" href="index.php" >Home</a></li>
                                        <li><a class="menu" href="index.php">about us</a></li>
                                        <li><a class="menu" href="index.php">Contact us</a></li>-->
                                        <li><a class="menu" href="signout.php"> Logout</a></li><br>
                                        <li style="float:right" class="style6"><h4>Logged in as <?php echo $_SESSION["username"]; ?></h4></li>
                                    </ul>
                                </div><!-- /navbar-collapse -->
                            </div><!-- / .container-fluid -->
                        </nav>
                    </div>
                </div>
            </div>
        </header> <!-- end of header area -->




        <section class="slider" id="home">
            <div class="container-fluid">
                <div class="row">
                    <div class="span12">
                        <div class="col-md-4">
                            <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
                                <div class="header-backup"></div>




                                <!--DATA INSERT ENDS HERE-->
                                <br>
                                <table>
                                    <tr>
                                        <td>                          

                                            <div>                                        
                                                <div class="left-sidebar">
                                                    <div class="item">

                                                        <list>
                                                        <li></li>
                                                        <li>
                                                            <div class="carousel-btn">
                                                                <form  method="POST">
                                                                    <button type="submit" id="submit7" class="button button1" style="width: 100px;" name="submit7">Verify Schools</button>
                                                                </form>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <div class="carousel-btn" >
                                                                <form action="school_not_upload.php" method="POST">
                                                                    <button type="submit" style="width: 100px;" class="button button1" id="submit1" name="submit1">Schools not uploaded</button>
                                                                </form>
                                                            </div>
                                                        </li>

                                                        <li>
                                                            <div class="carousel-btn">
                                                                <form action="#" method="POST">
                                                                    <button type="submit" id="submit2" class="button button1" style="width: 100px;" name="submit2">Schools uploaded</button>
                                                                </form>
                                                            </div>
                                                        </li>

                                                        <li>
                                                            <div class="carousel-btn">
                                                                <form  method="POST">
                                                                    <button type="submit" id="submit3" class="button button1" style="width: 100px;" name="submit3" >Process Results</button>
                                                                </form>
                                                            </div>
                                                        </li><!--check condition whether the upload complete if complete result_process_ready or result_process_pending-->

                                                        <li>
                                                            <div class="carousel-btn">
                                                                <form  method="POST">
                                                                    <button type="submit" id="submit4" class="button button1" style="width: 100px;" name="submit4">Verify Students</button>
                                                                </form>
                                                            </div>
                                                        </li>

                                                        <li>
                                                            <div class="carousel-btn">
                                                                <form method="POST">
                                                                    <button type="submit" id="submit5" class="button button1" style="width: 100px;" name="submit5">Publish Results</button>
                                                                </form>
                                                            </div>
                                                        </li>

                                                        <li>
<!--                                                            <div class="carousel-btn">
                                                                <form action="add_districts.php" method="POST">
                                                                    <button type="submit" id="submit6" class="button button1" style="width: 100px;height: 50px" name="submit6">Add Districts</button>
                                                                </form>
                                                            </div>
                                                        </li>

                                                        <li>
                                                            <div class="carousel-btn">
                                                                <form action="add_subdist.php" method="POST">
                                                                    <button type="submit" id="submit6" class="button button1" style="width: 100px;" name="submit7">Add Sub-Districts</button>
                                                                </form>
                                                            </div>-->
                                                        </li>
                                                        <br>
                                                        </list>
                                                    </div>
                                                </div></td><td>
                                            <div class="inner-content" style="left: 400px;">
                                                <center>
                                                    <h1 class="carousel">YOU CAN'T PUBLISH<br>RESULT NOT PROCESSED!!!</h1>
                                                    <!--<h3><a class="carousel-fade" href="result_process_pending.php/result_process_ready.php">Verify</a></h3>-->
                                                </center>     
                                            </div></td></tr></table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> 




        <!--footer starts here--> 
        <footer class="footer clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 footer-para">
                        <p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
                    </div>

                    <div class="col-xs-6 text-right">
                        <a href=""><i class="fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-skype"></i></a>
                    </div>
                </div>
            </div>
        </footer>





        <!-- script tags
        ============================================================= -->
        <script src="js/jquery-2.1.1.js"></script>
        <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        <script src="js/gmaps.js"></script>
        <script src="js/smoothscroll.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>