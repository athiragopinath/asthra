<!DOCTYPE html>
<?php
    include 'db.php';
	if(isset($_POST['submit']))
    {   
		$a=$_POST["user"];
		echo $a;
		$sql="SELECT * FROM r_school where email='$a'";
		$result=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($result);
		$d=$row['email'];
		//echo $d;
//		$e=$row['password'];
		if($a==$d)
		{
		$to = $a;
			$subject = "Shopper";
			$message ="<html>
			<head>
			<title>Forgot Password</title>
			</head>
			<body>
			<p>your username and password is below</p>
			<table>
			<tr>
			<th>UserName</th>
			<th>password</th>
			</tr>
			<tr>
			<td>'$a'</td>

			</tr>
			</table>
			</body>
			</html>";
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From: <athiragopinath011@gmail.com>' . "\r\n";
			$headers .= 'Cc: athiragopinath011@gmail.com' . "\r\n";
			mail($to,$subject,$message,$headers);
	}
	else
	{
		echo("enter correct password");
	}
	
    }
	
	?>
<html >
<head>
  <meta charset="UTF-8">
  <title>Shopper</title>
  
  
      		<link rel="stylesheet" href="assets/css/loginstyle.css" />

                <style>
                    
.button {
    background-color: orange;
    border: none;
    color: white;
    border-radius:25px 25px 25px 25px;
    padding: 10px 32px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 16px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button1 {
    background-color: orange; 
    color: orangered    ; 
    border: 2px solid white;
}

.button1:hover {
    background-color: orangered;
    color: black;
}

                </style>
  
</head>

<body>
 
  
<div class="container">
	<section id="content">
		<form action="forgot.php" method="post" name="mform">
			<h1>RECOVER</h1>
			<div>
				<input type="text" placeholder="Email" required="" id="username" name="user" />
			</div>
			<!--<div>
				<input type="password" placeholder="Password" required="" id="password" name="pass" />
			</div>
			-->
			<div style="margin-left:10px">
				<input type="submit" value="Get Password" name="submit" />
                                
			</div>
                        <div style="margin-left:100px">
        <button class="button button1" id="btn_Product_reg" onclick="location.href = 'login.php';" style="float: right;">BACK</button>
                        </div></form><!-- form -->
		
	</section><!-- content -->
</div><!-- container -->
</body>
  
    <script src="js/login.js"></script>
	
</div>
</body>
</html>
