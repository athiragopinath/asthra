
<?php
include 'db.php';
if(!isset($_SESSION["log_id"]))
{
header("location: ./");
}
if(session_status()==PHP_SESSION_NONE)
{
session_start();
}
if(isset($_POST['submit1']))
{
    $us_id=$_SESSION['log_id'];
    
    $sql3="SELECT `s_id` FROM `r_school` WHERE `log_id`='$us_id'";
    $result3= mysqli_query($con, $sql3);
    while($row=mysqli_fetch_array($result3))
    {
        $s=$row["s_id"];
    
//        echo  $s;
    
    
    $m="photo/".time()."".htmlspecialchars($_FILES['photo']['name']);
    move_uploaded_file($_FILES['photo']['tmp_name'], $m);
    
    //UPDATE `r_school` SET `file` = '0hjhj' WHERE `r_school`.`s_id` = 1;
    $sql1="UPDATE `r_school` SET `file`='$m',`upload_status`=2 WHERE `s_id`=$s";
    //$sql1="INSERT INTO `file`(`log_id`, `file`) VALUES ($us_id,'$m')";
    $result1=mysqli_query($con,$sql1) or die(mysqli_error($con));

    }

echo"<script>alert('Result Added');</script>";

//header("location:schoolhome.php");
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ASTHRA</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
</head>
<body>
	
	<!-- ====================================================
	header section -->
	<header class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-xs-5 header-logo">
					<br>
					<a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
				</div>

				<div class="col-md-7">
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>
					    </div>

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					      
					      <ul class="nav navbar-nav navbar-right">
<!--                                                  <li><a class="menu active" href="index.php" >Home</a></li>
                                                <li><a class="menu" href="index.php">about us</a></li>-->
					        <!--<li><a class="menu" href="#service">our services </a></li>-->
					        <!--<li><a class="menu" href="#contact">Contact us</a></li>-->
                                                <li><a class="menu" href="signout.php"> logout</a></li><br>
                                                <li style="float:right" class="style6"><h4>Logged in as <?php echo $_SESSION["username"];?></h4></li>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->

			
			

			<section class="slider" id="home">
				<div class="container-fluid">
					<div class="row">
                                            <div class="span12">
                                                 <div class="col-md-4">
					    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
							<div class="header-backup"></div>
<!--					         Wrapper for slides -->
<!--<h1>txt</h1>-->

<!--					         Controls -->
<!--					        <a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
					            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					            <span class="sr-only">Previous</span>
					        </a>
					        <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
					            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					            <span class="sr-only">Next</span>
					        </a>-->
					    </div>
                                            </div>
					</div>
				</div>
			</section><!-- end of slider section -->
                        <form name="sregister" class="form-stacked" id="form" method="POST"  enctype="multipart/form-data" onSubmit="return valid()">
                        <center>
                            <div class="control-group"><br>
                                <div align="center"><h3><strong>REUPLOAD YOUR RESULTS HERE!!</strong></h3></div><br>    
                                <label class="control-label"><b><center><h4>ADD RESULT FILE:</h4></center></b></label><br>
				<div class="controls">
                                    <input type="file" id="photo" name="photo" class="input-xlarge" required/><br>
				</div>
                                <div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" id="submit1" name="submit1" value="Add File"></div><br>
                        </center></form>
                                                                        <!-- footer starts here -->
			<footer class="footer clearfix">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 footer-para">
							<p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
						</div>

						<div class="col-xs-6 text-right">
							<a href=""><i class="fa fa-facebook"></i></a>
							<a href=""><i class="fa fa-twitter"></i></a>
							<a href=""><i class="fa fa-skype"></i></a>
						</div>
					</div>
				</div>
			</footer>



	

	<!-- script tags
	============================================================= -->
	<script src="js/jquery-2.1.1.js"></script>
	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="js/gmaps.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/custom.js"></script>
	
</body>
</html>