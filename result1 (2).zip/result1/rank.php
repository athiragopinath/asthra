<?php
include 'db.php';
if(!isset($_SESSION["year"]))
{
 echo"<script>alert('ADD YOUR YEAR FIRST!!');</script>";
  header("location:stud_result_select_yr.php");
}
$yr=$_SESSION['year'];

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>ASTHRA</title>
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=BenchNine:300,400,700' rel='stylesheet' type='text/css'>
    </head>
    <body>

        <!-- ====================================================
        header section -->
        <header class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-xs-5 header-logo">
                        <br>
                        <a href="index.html"><img src="img/logo1.png" alt="" height="150" width="150" class="img-responsive logo"></a>
                    </div>

                    <div class="col-md-7">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid nav-bar">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                                    <ul class="nav navbar-nav navbar-right"><form action="#" name="f1" method="post">
                                            <li>search<input placeholder="Rollnumber" type="text" name="search">
                                                <input  type="submit" name="sbutton" value="Search" ></li>

                                    </ul>
                                </div><!-- /navbar-collapse -->
                            </div><!-- / .container-fluid -->
                        </nav>
                    </div>
                </div>
            </div>
        </header> <!-- end of header area -->


        <br><br><br><br>
        <br><br><br><br>


        <section class="slider" id="home" align="center">
            <div class="container-fluid">
                <div class="row">
                    <div class="span12">
                        <?php
                        //   die('leo');
                        //   if (isset($_POST['sbutton'])) {
//                        var_dump($_POST);
//                        if(0)
                        if (isset($_POST['sbutton'])) {
                            echo "<script>alert('PLEASE CHECK THE YEAR AND ROLL NUMBER!!')</script>";
                            $rno = $_POST['search'];
//    echo $rno;
                            $sql12 = "SELECT * FROM r_result where roll_no='$rno' and pub_year='$yr'";
                            $res2 = mysqli_query($con, $sql12);
                            $row11 = mysqli_fetch_array($res2);
                            if ($row11) {
                                ?>
                                <table class="table table-condensed table-hover">

                                    <thead>
                                        <tr>
                                            <th><center>Rank</center></th>
                                    <th><center>Roll Number</center></th>
                                    <th><center>Mark</center></th>
                                    <th><center>Grade</center></th>
                                    <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sqldisp = "SELECT * FROM `r_result` where  pub_year='$yr' ORDER BY `tot_marks`";
                                        $resultdisp = mysqli_query($con, $sqldisp);
                                        $i = 0;
                                        $flag = 0;
                                        while ($row = mysqli_fetch_array($resultdisp)) {
                                            $i = $i + 1;
                                            if ($row['roll_no'] == $rno) {
                                                $flag = 1;
                                                ?>
                                                <tr>
                                                    <td><?php echo $i ?></td>
                                                    <td><?php echo $row['roll_no']; ?></td>
                                                    <td><?php echo$row['tot_marks']; ?></td>
                                                    <td><?php echo$row['grade']; ?></td>
                                                    <td><?php echo $i ?></td>
                                                </tr>
                                                <?php
                                            }
                                            //test_else
                                        }
                                        //test_else_close
                                    } else {
                                        ?>
                                                <tr><td>NO DATA FOUND!!!</td></tr><br><br>
                                    <a href="rank.php">GO BACK</a>
                                        <?php }
                                        ?>
                                        <tr>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                        </tr>


                                    </tbody>
                                </table>
                                <?php
                            } else {

                               
                                ?>

                                <!--code test-->

                                <table class="table table-condensed table-hover" id="reg_students">
                                    <thead>
                                        <tr>
                                            <th><center>Rank</center></th>
                                    <th><center>Roll Number</center></th>
                                    <th><center>Mark</center></th>
                                    <th><center>Grade</center></th>
                                    <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sqldisp = "SELECT * FROM `r_result`where pub_year='$yr' ORDER BY `tot_marks` DESC";
                                        $resultdisp = mysqli_query($con, $sqldisp);
                                        $i = 0;
                                        while ($row = mysqli_fetch_array($resultdisp)) {
                                            $i = $i + 1;
                                            ?>
                                            <tr>
                                                <td><?php echo $i ?></td>
                                                <td><?php echo $row['roll_no']; ?></td>
                                                <td><?php echo$row['tot_marks']; ?></td>
                                                <td><?php echo$row['grade']; ?></td>

                                            </tr>
                                            <?php
                                        }
                                        ?>
                                        <tr>
                                            <td> </td>
                                            <td> </td>
                                            <td> </td>
                                        </tr>


                                    </tbody>
                                </table><?php } ?>
                    </div>
                </div>
            </div>	
        </section><!-- end of slider section -->




        <!-- footer starts here -->
        <footer class="footer clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-xs-6 footer-para">
                        <p>Template By <a href="http://wptechnews.com/">WpTechnews</a>&copy;All right reserved</p>
                    </div>

                    <div class="col-xs-6 text-right">
                        <a href=""><i class="fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-skype"></i></a>
                    </div>
                </div>
            </div>
        </footer>





        <!-- script tags
        ============================================================= -->
        <script src="js/jquery-2.1.1.js"></script>
        <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        <script src="js/gmaps.js"></script>
        <script src="js/smoothscroll.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>

    </body>
</html>
